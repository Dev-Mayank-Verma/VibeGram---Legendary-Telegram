# VibeGram — Phase 1 (UI Build)

An all-in-one chat + social app — WhatsApp-style chats, Telegram-style
folders & channels, Instagram-style reels, plus stories and calls — in
one bottom-nav shell. Built with Flutter. This phase is UI-complete
and locally interactive; the real backend (Firebase) is the next step.

## What's included
- Splash screen → **Demo login** (name only, no OTP yet — real phone +
  OTP auth is a planned phase)
- **Bottom navigation, 5 tabs:**
  - **Chats** — folder pills (All / Unread / Groups / Personal), unread
    badges, smart timestamps, group messages show the sender's name
    and a "You:" prefix like real chat apps
  - **Stories** — My Story + contacts' 24h story ring list
  - **Channels** — Telegram-style one-way broadcast list → tap into a
    channel to see its post feed + subscribe/unsubscribe
  - **Calls** — recent calls list (incoming/outgoing/missed)
  - **Reels** — Instagram-style vertical swipe feed with like/comment/
    share icons (video is a gradient placeholder for now)
- Individual chat screen — sending a message actually works (in-memory)
  with a short auto-reply so it feels alive during a demo
- **Message actions** — long-press any message for Reply / Copy /
  Delete; replies show a quoted preview both above the input and
  inside the sent bubble
- **Mic ⇄ Send button** — switches automatically based on whether
  you've typed anything, like a real chat app
- **Attachments** — tap the paperclip for Photo / Camera / Document /
  Audio (inserts a labeled placeholder bubble — real upload needs
  Firebase Storage, see below)
- **Calling screen** — tapping the call/video icons (in a chat or the
  Calls tab) opens a real calling UI: connecting → live timer →
  mute/speaker toggle → end call. No audio/video is actually
  transmitted yet — see the WebRTC note below
- **New group creation** — pick contacts, name the group, and it opens
  as a real, usable group chat
- **Real calling (Agora)** — the call/video buttons now use the actual
  Agora RTC engine (mic/camera permissions, mute, speaker, live
  duration timer). App ID is injected at build time
  (`--dart-define=AGORA_APP_ID=...`), never hardcoded. The App
  Certificate is NOT in this app anywhere — see "Agora calling status"
  below for the one remaining step before calls fully connect
- **Real phone login (Firebase Auth)** — enter a number, get a real
  SMS OTP, verify it, land in the app. A "Skip for now (demo mode)"
  link stays available as a fallback in case phone auth needs more
  console setup (SHA-1 fingerprint, Play Integrity) before it works
  end-to-end on your build
- New chat flow, profile screen, WhatsApp-style overflow menu
- Animated splash screen

## Firebase login status
Real phone OTP login is wired in (`AuthService`, `PhoneLoginScreen`,
`OtpScreen`). The CI workflow now also:
- Adds the Google Services Gradle plugin (needed for any Firebase
  service to work on Android)
- Writes your `google-services.json` from the `GOOGLE_SERVICES_JSON`
  GitHub secret into the right folder at build time

This is the riskiest change so far — if the next Actions run fails,
the "Add Firebase Google Services plugin" or "Set up Flutter" /
"Build debug APK" step is the most likely place. Paste me that step's
full log and I'll fix it.

If login sends the SMS but verification fails, the most common cause
is a missing SHA-1/SHA-256 fingerprint on the Firebase Android app —
happy to walk through generating and adding that when you hit it.

**Chats/groups/channels still use local demo data** — migrating those
to real Firestore is the next piece, kept separate from this login
change on purpose so we can confirm the Firebase/Gradle wiring itself
is solid before building more on top of it.

## Agora calling status — one step left
The app-side code is complete and safe (App ID only, no Certificate).
What's still needed before two phones can actually hear each other:

1. **Deploy the token server** — the code is ready at `/functions`
   (`generateAgoraToken`, a Firebase Cloud Function). It reads the
   Agora App ID + Certificate from Secret Manager at runtime — the
   Certificate is set only when deploying this function, never
   committed anywhere.
2. Once deployed, you'll get a URL like
   `https://us-central1-<project-id>.cloudfunctions.net/generateAgoraToken`.
   Add that as the `AGORA_TOKEN_URL` GitHub secret (same place as
   `AGORA_APP_ID`) and rebuild — calling will then work end-to-end.
3. Deploying a Cloud Function needs the Blaze (pay-as-you-go) plan on
   Firebase, and a one-time deploy step. Ask when you're ready and
   we'll go through it.

Until then, opening the call screen will show a clear "token server
not deployed yet" message instead of connecting — that's expected,
not a bug.

**Testing note**: there's no push-based "incoming call" signaling yet
(needs FCM). To test between two phones right now, both need to call
the exact same contact name — that opens the same Agora channel on
both ends.

## How this will actually work (architecture)
Everything above runs on local/dummy data right now. To make it a real
app, each piece maps to a Firebase service:

| Feature | Firebase service |
|---|---|
| Login | Firebase Authentication (Phone OTP) |
| Chats, Groups, Channels, folders | Cloud Firestore (real-time) |
| Photos, story media, reel videos | Firebase Storage |
| Push notifications | Firebase Cloud Messaging |
| Story 24h auto-expiry, feed logic | Cloud Functions |
| **Voice/video calls** | **Not Firebase** — needs a WebRTC provider like Agora, Stream Video, or Twilio (Firebase has no built-in calling) |

To wire this in, you'll need to create a project in the
[Firebase console](https://console.firebase.google.com), add an
Android/iOS app there, and drop in the generated config files —
I'll walk you through that step-by-step whenever you're ready to move
off demo data.

## Honest timeline, phase by phase (real app, ~1 year)
- **Month 1** — Real Firebase Auth (phone OTP) + Firestore-backed
  chats/groups/folders, replacing today's in-memory data
- **Month 2** — Media sharing (photos, videos, docs, voice notes) via
  Firebase Storage
- **Month 3** — Stories: real 24h expiry (Cloud Functions) + push
  notifications (FCM)
- **Months 4–5** — Channels: admin posting, subscriber management,
  channel discovery
- **Months 5–6** — Voice/video calls (the hardest piece — WebRTC
  provider integration, not just Firebase)
- **Months 6–8** — Reels: real video upload, compression, and feed
- **Months 8–9** — Security & polish: spam/abuse controls, rate
  limiting, encryption for chats, bug fixes across every tab
- **Months 9–10** — Play Store prep: privacy policy, terms of
  service, content moderation flow (required for a chat/social app)
- **Months 10–12** — Buffer for feedback from your 1.5k audience,
  performance tuning at real usage

This is a genuinely buildable roadmap for a working, real app — not a
toy — if we keep shipping one solid piece at a time the way we have
been. It won't match WhatsApp/Telegram/Instagram's scale or R&D
(that's teams of hundreds over many years), but a fully-functional
app with this feature set for your audience is realistic in this
timeframe.

## How to run
This zip has `lib/`, `pubspec.yaml`, and `analysis_options.yaml`. It
does **not** include Android/iOS native folders — those are best
freshly generated by Flutter itself:

1. Install Flutter: https://flutter.dev/docs/get-started/install
2. Create a fresh project shell:
   ```
   flutter create vibegram
   ```
3. From this downloaded folder, copy `lib/`, `pubspec.yaml`, and
   `analysis_options.yaml` into the new `vibegram` project, replacing
   the auto-generated versions.
4. Inside that project folder, run:
   ```
   flutter pub get
   flutter run
   ```

## About the name & design
"VibeGram" is an original name and independently written UI code —
inspired by the layout/UX conventions of WhatsApp, Telegram, and
Instagram, but not using their logos, icons, or brand names. Two
things worth a quick check before you invest in branding/marketing:
1. Since "-Gram" echoes Instagram/Telegram's naming, a quick trademark
   search (Play Store + your country's trademark registry) before you
   commit hard to the name is a cheap insurance step.
2. Keep your own app icon — Play Store removes apps whose icon/UI is
   too close to a bigger app's branding.

## Project structure
```
lib/
  main.dart                 — app entry, theme, providers
  theme/app_colors.dart     — color palette
  models/                   — Message, ChatModel, Contact, Channel, Reel
  data/dummy_data.dart      — sample chats, groups, channels, reels
  providers/                — ChatProvider, ChannelProvider, UserProvider
  services/agora_service.dart — real Agora call engine wrapper
  screens/
    splash_screen.dart      — animated
    auth/demo_login_screen.dart
    home/home_screen.dart + tabs/ (chats, stories, channels, calls, reels)
    chat/chat_screen.dart
    calls/calling_screen.dart — real Agora calling UI
    channels/channel_detail_screen.dart
    contacts/new_chat_screen.dart + new_group_screen.dart
    profile/profile_screen.dart
  widgets/                  — avatar, message bubble, chat list tile
functions/                  — Cloud Function: Agora token server (not yet deployed)
  index.js
  package.json
```
