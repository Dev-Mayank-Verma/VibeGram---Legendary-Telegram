import '../models/chat_model.dart';
import '../models/channel_model.dart';
import '../models/contact_model.dart';
import '../models/message_model.dart';
import '../models/reel_model.dart';

class DummyData {
  static List<ChatModel> getSampleChats() {
    final now = DateTime.now();
    return [
      ChatModel(
        id: '1',
        name: 'Rohan Sharma',
        avatarInitial: 'R',
        avatarColorSeed: 1,
        isOnline: true,
        unreadCount: 2,
        messages: [
          Message(
            id: 'm1',
            text: 'Kal party mein aa raha hai na?',
            time: now.subtract(const Duration(minutes: 12)),
            isSentByMe: false,
          ),
          Message(
            id: 'm2',
            text: 'Haan bhai zaroor 🎉',
            time: now.subtract(const Duration(minutes: 10)),
            isSentByMe: true,
            status: MessageStatus.read,
          ),
          Message(
            id: 'm3',
            text: 'Time bata dena',
            time: now.subtract(const Duration(minutes: 2)),
            isSentByMe: false,
          ),
        ],
      ),
      ChatModel(
        id: '2',
        name: 'Priya Verma',
        avatarInitial: 'P',
        avatarColorSeed: 2,
        messages: [
          Message(
            id: 'm1',
            text: 'Project file bhej di hai check karlo',
            time: now.subtract(const Duration(hours: 1)),
            isSentByMe: false,
          ),
          Message(
            id: 'm2',
            text: 'Thanks, dekh leta hu',
            time: now.subtract(const Duration(minutes: 55)),
            isSentByMe: true,
            status: MessageStatus.read,
          ),
        ],
      ),
      ChatModel(
        id: '4',
        name: 'Mom',
        avatarInitial: 'M',
        avatarColorSeed: 4,
        isOnline: true,
        messages: [
          Message(
            id: 'm1',
            text: 'Khana kha liya?',
            time: now.subtract(const Duration(hours: 5)),
            isSentByMe: false,
          ),
          Message(
            id: 'm2',
            text: 'Haan mom, aap batao',
            time: now.subtract(const Duration(hours: 4, minutes: 50)),
            isSentByMe: true,
            status: MessageStatus.read,
          ),
        ],
      ),
      ChatModel(
        id: '5',
        name: 'Amit Kumar',
        avatarInitial: 'A',
        avatarColorSeed: 5,
        messages: [
          Message(
            id: 'm1',
            text: 'Bhai match dekha?',
            time: now.subtract(const Duration(days: 1)),
            isSentByMe: false,
          ),
          Message(
            id: 'm2',
            text: 'Nahi yaar, highlights dekhunga',
            time: now.subtract(const Duration(days: 1)).add(const Duration(minutes: 3)),
            isSentByMe: true,
            status: MessageStatus.delivered,
          ),
        ],
      ),
      ChatModel(
        id: '6',
        name: 'Neha Singh',
        avatarInitial: 'N',
        avatarColorSeed: 6,
        messages: [
          Message(
            id: 'm1',
            text: 'Good morning! ☀️',
            time: now.subtract(const Duration(days: 2)),
            isSentByMe: false,
          ),
        ],
      ),
      ChatModel(
        id: '7',
        name: 'College Friends',
        avatarInitial: 'C',
        avatarColorSeed: 7,
        isGroup: true,
        unreadCount: 3,
        messages: [
          Message(
            id: 'g1',
            text: 'Reunion plan kar rahe hai',
            time: now.subtract(const Duration(minutes: 40)),
            isSentByMe: false,
            senderName: 'Karan',
          ),
          Message(
            id: 'g2',
            text: 'Date fix karo pehle',
            time: now.subtract(const Duration(minutes: 35)),
            isSentByMe: false,
            senderName: 'Sana',
          ),
          Message(
            id: 'g3',
            text: 'Mai free hu weekend pe',
            time: now.subtract(const Duration(minutes: 30)),
            isSentByMe: true,
            status: MessageStatus.read,
          ),
        ],
      ),
      ChatModel(
        id: '8',
        name: 'Family Group',
        avatarInitial: 'F',
        avatarColorSeed: 8,
        isGroup: true,
        messages: [
          Message(
            id: 'g1',
            text: 'Sunday lunch ghar pe, sab aana',
            time: now.subtract(const Duration(hours: 3)),
            isSentByMe: false,
            senderName: 'Papa',
          ),
        ],
      ),
    ];
  }

  static List<Contact> getContacts() {
    return const [
      Contact(name: 'Rohan Sharma', initial: 'R', seed: 1),
      Contact(name: 'Priya Verma', initial: 'P', seed: 2),
      Contact(name: 'Amit Kumar', initial: 'A', seed: 5),
      Contact(name: 'Neha Singh', initial: 'N', seed: 6),
      Contact(name: 'Karan Mehta', initial: 'K', seed: 7),
      Contact(name: 'Sana Khan', initial: 'S', seed: 8),
      Contact(name: 'Vikram Rao', initial: 'V', seed: 9),
    ];
  }

  static List<ChannelModel> getSampleChannels() {
    final now = DateTime.now();
    return [
      ChannelModel(
        id: 'c1',
        name: 'Tech News Daily',
        avatarInitial: 'T',
        avatarColorSeed: 2,
        subscriberCount: 128000,
        isSubscribed: true,
        posts: [
          ChannelPost(
            id: 'p1',
            text: 'Naya AI model launch hua hai — full details thread mein.',
            time: now.subtract(const Duration(hours: 2)),
            likeCount: 342,
          ),
          ChannelPost(
            id: 'p2',
            text: 'Weekly roundup: is hafte ki top 5 tech stories.',
            time: now.subtract(const Duration(hours: 20)),
            likeCount: 198,
          ),
        ],
      ),
      ChannelModel(
        id: 'c2',
        name: 'Cricket Updates',
        avatarInitial: 'C',
        avatarColorSeed: 5,
        subscriberCount: 542000,
        posts: [
          ChannelPost(
            id: 'p1',
            text: 'Match highlights aa gaye — link niche.',
            time: now.subtract(const Duration(hours: 5)),
            likeCount: 890,
          ),
        ],
      ),
      ChannelModel(
        id: 'c3',
        name: 'VibeGram Official',
        avatarInitial: 'V',
        avatarColorSeed: 1,
        subscriberCount: 15400,
        isSubscribed: true,
        posts: [
          ChannelPost(
            id: 'p1',
            text: 'Welcome to VibeGram! New features roll out here first.',
            time: now.subtract(const Duration(days: 1)),
            likeCount: 76,
          ),
        ],
      ),
    ];
  }

  static List<ReelModel> getSampleReels() {
    return [
      ReelModel(id: 'r1', username: 'rohan.codes', caption: 'Weekend project ban gaya 🚀', gradientSeed: 0, likeCount: 1240),
      ReelModel(id: 'r2', username: 'priya.travels', caption: 'Sunset from the hills 🌄', gradientSeed: 1, likeCount: 3520),
      ReelModel(id: 'r3', username: 'foodie.amit', caption: 'Street food tour, part 2', gradientSeed: 2, likeCount: 892),
      ReelModel(id: 'r4', username: 'neha.dances', caption: 'New choreography 💃', gradientSeed: 3, likeCount: 5210),
    ];
  }
}
