import '../models/channel_model.dart';
import '../models/contact_model.dart';
import '../models/reel_model.dart';

/// Chats/groups now come from real Firestore data (see ChatProvider).
/// Channels, Reels, and the contact-picker-for-Stories still use this
/// local sample data until their own migrations happen.
class DummyData {
  static List<Contact> getContacts() {
    return const [
      Contact(name: 'Rohan Sharma', initial: 'R', seed: 1),
      Contact(name: 'Priya Verma', initial: 'P', seed: 2),
      Contact(name: 'Amit Kumar', initial: 'A', seed: 5),
      Contact(name: 'Neha Singh', initial: 'N', seed: 6),
      Contact(name: 'Karan Mehta', initial: 'K', seed: 7),
      Contact(name: 'Sana Khan', initial: 'S', seed: 8),
      Contact(name: 'Vikram Rao', initial: 'V', seed: 9),
    ];
  }

  static List<ChannelModel> getSampleChannels() {
    final now = DateTime.now();
    return [
      ChannelModel(
        id: 'c1',
        name: 'Tech News Daily',
        avatarInitial: 'T',
        avatarColorSeed: 2,
        subscriberCount: 128000,
        isSubscribed: true,
        posts: [
          ChannelPost(
            id: 'p1',
            text: 'Naya AI model launch hua hai — full details thread mein.',
            time: now.subtract(const Duration(hours: 2)),
            likeCount: 342,
          ),
          ChannelPost(
            id: 'p2',
            text: 'Weekly roundup: is hafte ki top 5 tech stories.',
            time: now.subtract(const Duration(hours: 20)),
            likeCount: 198,
          ),
        ],
      ),
      ChannelModel(
        id: 'c2',
        name: 'Cricket Updates',
        avatarInitial: 'C',
        avatarColorSeed: 5,
        subscriberCount: 542000,
        posts: [
          ChannelPost(
            id: 'p1',
            text: 'Match highlights aa gaye — link niche.',
            time: now.subtract(const Duration(hours: 5)),
            likeCount: 890,
          ),
        ],
      ),
      ChannelModel(
        id: 'c3',
        name: 'VibeGram Official',
        avatarInitial: 'V',
        avatarColorSeed: 1,
        subscriberCount: 15400,
        isSubscribed: true,
        posts: [
          ChannelPost(
            id: 'p1',
            text: 'Welcome to VibeGram! New features roll out here first.',
            time: now.subtract(const Duration(days: 1)),
            likeCount: 76,
          ),
        ],
      ),
    ];
  }

  static List<ReelModel> getSampleReels() {
    return [
      ReelModel(id: 'r1', username: 'rohan.codes', caption: 'Weekend project ban gaya 🚀', gradientSeed: 0, likeCount: 1240),
      ReelModel(id: 'r2', username: 'priya.travels', caption: 'Sunset from the hills 🌄', gradientSeed: 1, likeCount: 3520),
      ReelModel(id: 'r3', username: 'foodie.amit', caption: 'Street food tour, part 2', gradientSeed: 2, likeCount: 892),
      ReelModel(id: 'r4', username: 'neha.dances', caption: 'New choreography 💃', gradientSeed: 3, likeCount: 5210),
    ];
  }
}
