import 'package:flutter/foundation.dart';
import '../data/dummy_data.dart';
import '../models/channel_model.dart';

class ChannelProvider extends ChangeNotifier {
  final List<ChannelModel> _channels = DummyData.getSampleChannels();

  List<ChannelModel> get channels => _channels;

  ChannelModel getChannelById(String id) => _channels.firstWhere((c) => c.id == id);

  void toggleSubscribe(String id) {
    final channel = getChannelById(id);
    channel.isSubscribed = !channel.isSubscribed;
    notifyListeners();
  }
}
