import 'package:flutter/foundation.dart';

/// Holds the current user's profile. Supports both a real phone-verified
/// user (set via setPhoneUser after OTP success) and the demo fallback
/// (set via demoLogin) for quick testing without SMS.
class UserProvider extends ChangeNotifier {
  String _name = '';
  String? _phoneNumber;
  int _avatarColorSeed = 0;
  bool _isDemo = false;

  String get name => _name;
  String? get phoneNumber => _phoneNumber;
  int get avatarColorSeed => _avatarColorSeed;
  bool get isLoggedIn => _name.isNotEmpty || _phoneNumber != null;
  bool get isDemo => _isDemo;

  void demoLogin(String name) {
    _name = name.trim();
    _phoneNumber = null;
    _avatarColorSeed = _name.isNotEmpty ? _name.codeUnitAt(0) : 0;
    _isDemo = true;
    notifyListeners();
  }

  void setPhoneUser(String phoneNumber) {
    _phoneNumber = phoneNumber;
    _name = phoneNumber; // replace with a real display name once profile editing lands
    _avatarColorSeed = phoneNumber.isNotEmpty ? phoneNumber.codeUnitAt(phoneNumber.length - 1) : 0;
    _isDemo = false;
    notifyListeners();
  }

  void logout() {
    _name = '';
    _phoneNumber = null;
    _isDemo = false;
    notifyListeners();
  }
}
