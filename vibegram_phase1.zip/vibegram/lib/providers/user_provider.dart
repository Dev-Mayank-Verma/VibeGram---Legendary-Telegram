import 'package:flutter/foundation.dart';

/// Holds the current user's demo profile.
/// NOTE: This is Phase 1 demo auth only — no phone number or OTP yet.
/// Real phone + OTP verification will replace this in a later phase.
class UserProvider extends ChangeNotifier {
  String _name = '';
  int _avatarColorSeed = 0;

  String get name => _name;
  int get avatarColorSeed => _avatarColorSeed;
  bool get isLoggedIn => _name.isNotEmpty;

  void demoLogin(String name) {
    _name = name.trim();
    _avatarColorSeed = _name.isNotEmpty ? _name.codeUnitAt(0) : 0;
    notifyListeners();
  }

  void logout() {
    _name = '';
    notifyListeners();
  }
}
