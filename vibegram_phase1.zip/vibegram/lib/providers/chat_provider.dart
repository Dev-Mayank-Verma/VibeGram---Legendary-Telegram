import 'package:flutter/foundation.dart';
import '../data/dummy_data.dart';
import '../models/chat_model.dart';
import '../models/message_model.dart';

/// Holds all chats in memory for this phase (no backend yet — data resets
/// when the app restarts). Real-time sync via Firebase comes later.
class ChatProvider extends ChangeNotifier {
  final List<ChatModel> _chats = DummyData.getSampleChats();

  /// Chats sorted by most recent message first, like a real chat list.
  List<ChatModel> get chats {
    final sorted = [..._chats];
    sorted.sort((a, b) {
      final aTime = a.lastMessage?.time ?? DateTime(2000);
      final bTime = b.lastMessage?.time ?? DateTime(2000);
      return bTime.compareTo(aTime);
    });
    return sorted;
  }

  ChatModel getChatById(String id) => _chats.firstWhere((c) => c.id == id);

  ChatModel addChat({required String name, required String initial, required int seed}) {
    final newChat = ChatModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
      avatarInitial: initial,
      avatarColorSeed: seed,
    );
    _chats.add(newChat);
    notifyListeners();
    return newChat;
  }

  ChatModel createGroup({required String name, required List<String> memberNames}) {
    final newGroup = ChatModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
      avatarInitial: name.isNotEmpty ? name[0] : 'G',
      avatarColorSeed: name.isNotEmpty ? name.codeUnitAt(0) : 0,
      isGroup: true,
      messages: [
        Message(
          id: '${DateTime.now().millisecondsSinceEpoch}_sys',
          text: 'You created the group "$name" with ${memberNames.join(", ")}',
          time: DateTime.now(),
          isSentByMe: true,
          status: MessageStatus.read,
        ),
      ],
    );
    _chats.add(newGroup);
    notifyListeners();
    return newGroup;
  }

  void sendMessage(
    String chatId,
    String text, {
    MessageType type = MessageType.text,
    String? replyToText,
    String? replyToSender,
  }) {
    if (text.trim().isEmpty) return;
    final chat = getChatById(chatId);
    chat.messages.add(
      Message(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        text: text.trim(),
        time: DateTime.now(),
        isSentByMe: true,
        type: type,
        replyToText: replyToText,
        replyToSender: replyToSender,
      ),
    );
    notifyListeners();
    _scheduleAutoReply(chatId);
  }

  void deleteMessage(String chatId, String messageId) {
    final chat = getChatById(chatId);
    chat.messages.removeWhere((m) => m.id == messageId);
    notifyListeners();
  }

  void _scheduleAutoReply(String chatId) {
    Future.delayed(const Duration(milliseconds: 1200), () {
      final chat = getChatById(chatId);
      chat.messages.add(
        Message(
          id: '${DateTime.now().millisecondsSinceEpoch}_r',
          text: _autoReplies[chat.messages.length % _autoReplies.length],
          time: DateTime.now(),
          isSentByMe: false,
        ),
      );
      notifyListeners();
    });
  }

  void markAsRead(String chatId) {
    final chat = getChatById(chatId);
    if (chat.unreadCount != 0) {
      chat.unreadCount = 0;
      notifyListeners();
    }
  }

  static const List<String> _autoReplies = [
    'Haan bolo',
    'Ok noted',
    'Achha, theek hai',
    'Sahi baat hai',
    'Kal baat karte hain',
  ];
}
