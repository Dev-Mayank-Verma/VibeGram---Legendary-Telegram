import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import '../models/chat_model.dart';
import '../models/message_model.dart';

/// Chats and messages now live in Firestore. This class subscribes to
/// the signed-in user's chats automatically (via authStateChanges) and
/// keeps [chats] up to date in real time.
///
/// Note: queries below deliberately avoid combining arrayContains with
/// orderBy/extra where clauses in Firestore itself -- that needs a
/// composite index. Sorting/filtering happens client-side in Dart
/// instead, which is simpler and fine at this scale.
class ChatProvider extends ChangeNotifier {
  final _firestore = FirebaseFirestore.instance;
  StreamSubscription<QuerySnapshot>? _chatsSub;
  List<ChatModel> _chats = [];
  String? _currentUid;
  bool _loading = true;
  String? _error;

  List<ChatModel> get chats => _chats;
  bool get loading => _loading;
  String? get error => _error;

  ChatProvider() {
    FirebaseAuth.instance.authStateChanges().listen(_onAuthChanged);
  }

  void _onAuthChanged(User? user) {
    _chatsSub?.cancel();
    _currentUid = user?.uid;
    _chats = [];
    _error = null;
    _loading = user != null;
    notifyListeners();

    if (user == null) return;

    _chatsSub = _firestore
        .collection('chats')
        .where('participantIds', arrayContains: user.uid)
        .snapshots()
        .listen(
      (snapshot) {
        final list = snapshot.docs.map(_chatFromDoc).toList();
        list.sort((a, b) {
          final aTime = a.lastMessageTime ?? DateTime(2000);
          final bTime = b.lastMessageTime ?? DateTime(2000);
          return bTime.compareTo(aTime);
        });
        _chats = list;
        _loading = false;
        _error = null;
        notifyListeners();
      },
      onError: (e) {
        _loading = false;
        _error = 'Could not load chats: $e';
        notifyListeners();
      },
    );
  }

  ChatModel _chatFromDoc(QueryDocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    final isGroup = data['isGroup'] as bool? ?? false;
    String name;
    int avatarSeed;

    if (isGroup) {
      name = data['name'] as String? ?? 'Group';
      avatarSeed = data['avatarColorSeed'] as int? ?? 0;
    } else {
      final names = Map<String, dynamic>.from(data['participantNames'] ?? {});
      final seeds = Map<String, dynamic>.from(data['participantSeeds'] ?? {});
      final ids = List<String>.from(data['participantIds'] ?? []);
      final otherUid = ids.firstWhere((id) => id != _currentUid, orElse: () => '');
      name = names[otherUid] as String? ?? 'Unknown';
      avatarSeed = (seeds[otherUid] as int?) ?? 0;
    }

    return ChatModel(
      id: doc.id,
      name: name,
      avatarInitial: name.isNotEmpty ? name[0].toUpperCase() : '?',
      avatarColorSeed: avatarSeed,
      isGroup: isGroup,
      lastMessageText: data['lastMessageText'] as String? ?? '',
      lastMessageTime: (data['lastMessageTime'] as Timestamp?)?.toDate(),
      lastMessageSentByMe: data['lastMessageSenderId'] == _currentUid,
      unreadCount: 0, // read-receipt tracking is a follow-up piece
    );
  }

  ChatModel? getChatById(String id) {
    for (final c in _chats) {
      if (c.id == id) return c;
    }
    return null;
  }

  /// Live message stream for one chat -- call once and cache it
  /// (e.g. in initState), don't call fresh on every build.
  Stream<List<Message>> messagesStream(String chatId) {
    return _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .orderBy('time')
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) {
              final data = doc.data();
              return Message(
                id: doc.id,
                text: data['text'] as String? ?? '',
                time: (data['time'] as Timestamp?)?.toDate() ?? DateTime.now(),
                isSentByMe: data['senderId'] == _currentUid,
                senderName: data['senderName'] as String?,
                type: MessageType.values.firstWhere(
                  (t) => t.name == data['type'],
                  orElse: () => MessageType.text,
                ),
                replyToText: data['replyToText'] as String?,
                replyToSender: data['replyToSender'] as String?,
              );
            }).toList());
  }

  /// Starts (or reuses) a 1:1 chat with [otherUid].
  Future<String> startChat({
    required String otherUid,
    required String otherName,
    required int otherAvatarSeed,
  }) async {
    final me = _currentUid;
    if (me == null) throw Exception('Not logged in');

    final mine = await _firestore.collection('chats').where('participantIds', arrayContains: me).get();
    for (final doc in mine.docs) {
      final data = doc.data();
      if (data['isGroup'] == true) continue;
      final ids = List<String>.from(data['participantIds'] ?? []);
      if (ids.contains(otherUid)) return doc.id;
    }

    final myProfile = await _firestore.collection('users').doc(me).get();
    final myData = myProfile.data() ?? {};

    final newDoc = await _firestore.collection('chats').add({
      'isGroup': false,
      'participantIds': [me, otherUid],
      'participantNames': {me: myData['name'] ?? '', otherUid: otherName},
      'participantSeeds': {me: myData['avatarColorSeed'] ?? 0, otherUid: otherAvatarSeed},
      'lastMessageText': '',
      'lastMessageSenderId': null,
      'lastMessageTime': FieldValue.serverTimestamp(),
      'createdAt': FieldValue.serverTimestamp(),
      'createdBy': me,
    });

    return newDoc.id;
  }

  Future<String> createGroup({
    required String name,
    required List<Map<String, dynamic>> members,
  }) async {
    final me = _currentUid;
    if (me == null) throw Exception('Not logged in');

    final myProfile = await _firestore.collection('users').doc(me).get();
    final myData = myProfile.data() ?? {};

    final participantIds = [me, ...members.map((m) => m['uid'] as String)];
    final participantNames = <String, dynamic>{me: myData['name'] ?? ''};
    final participantSeeds = <String, dynamic>{me: myData['avatarColorSeed'] ?? 0};
    for (final m in members) {
      participantNames[m['uid'] as String] = m['name'];
      participantSeeds[m['uid'] as String] = m['avatarColorSeed'];
    }

    final doc = await _firestore.collection('chats').add({
      'isGroup': true,
      'name': name,
      'avatarColorSeed': name.isNotEmpty ? name.codeUnitAt(0) : 0,
      'participantIds': participantIds,
      'participantNames': participantNames,
      'participantSeeds': participantSeeds,
      'lastMessageText': 'Group created',
      'lastMessageSenderId': me,
      'lastMessageTime': FieldValue.serverTimestamp(),
      'createdAt': FieldValue.serverTimestamp(),
      'createdBy': me,
    });

    return doc.id;
  }

  Future<void> sendMessage(
    String chatId,
    String text, {
    MessageType type = MessageType.text,
    String? replyToText,
    String? replyToSender,
  }) async {
    final me = _currentUid;
    if (me == null || text.trim().isEmpty) return;

    final myProfile = await _firestore.collection('users').doc(me).get();
    final myName = (myProfile.data()?['name'] as String?) ?? '';

    final chatRef = _firestore.collection('chats').doc(chatId);
    await chatRef.collection('messages').add({
      'senderId': me,
      'senderName': myName,
      'text': text.trim(),
      'type': type.name,
      'time': FieldValue.serverTimestamp(),
      'replyToText': replyToText,
      'replyToSender': replyToSender,
    });

    await chatRef.update({
      'lastMessageText': type == MessageType.text ? text.trim() : _labelFor(type),
      'lastMessageSenderId': me,
      'lastMessageTime': FieldValue.serverTimestamp(),
    });
  }

  String _labelFor(MessageType type) {
    switch (type) {
      case MessageType.image:
        return '📷 Photo';
      case MessageType.document:
        return '📄 Document';
      case MessageType.audio:
        return '🎤 Voice message';
      case MessageType.text:
        return '';
    }
  }

  Future<void> deleteMessage(String chatId, String messageId) async {
    await _firestore.collection('chats').doc(chatId).collection('messages').doc(messageId).delete();
  }

  @override
  void dispose() {
    _chatsSub?.cancel();
    super.dispose();
  }
}
