import 'package:flutter/material.dart';

/// Color palette inspired by the familiar teal-and-green chat-app look.
/// These are independently chosen hex values used to build our own UI —
/// not copied logos, icons, or other brand assets.
class AppColors {
  AppColors._();

  static const Color appBarDark = Color(0xFF075E54);
  static const Color tealMedium = Color(0xFF128C7E);
  static const Color accentGreen = Color(0xFF25D366);
  static const Color chatBackground = Color(0xFFECE5DD);
  static const Color bubbleSent = Color(0xFFDCF8C6);
  static const Color bubbleReceived = Color(0xFFFFFFFF);
  static const Color unreadBadge = Color(0xFF25D366);
  static const Color tickBlue = Color(0xFF34B7F1);
  static const Color iconGrey = Color(0xFF8696A0);
  static const Color dividerGrey = Color(0xFFE0E0E0);
  static const Color textPrimary = Color(0xFF111B21);
  static const Color textSecondary = Color(0xFF667781);
}
