class ReelModel {
  final String id;
  final String username;
  final String caption;
  final int gradientSeed;
  int likeCount;
  bool isLiked;

  ReelModel({
    required this.id,
    required this.username,
    required this.caption,
    required this.gradientSeed,
    this.likeCount = 0,
    this.isLiked = false,
  });
}
