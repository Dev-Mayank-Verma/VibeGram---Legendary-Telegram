import 'message_model.dart';

class ChatModel {
  final String id;
  final String name;
  final String avatarInitial;
  final int avatarColorSeed;
  final bool isGroup;
  bool isOnline;
  int unreadCount;
  final List<Message> messages;

  ChatModel({
    required this.id,
    required this.name,
    required this.avatarInitial,
    required this.avatarColorSeed,
    this.isGroup = false,
    this.isOnline = false,
    this.unreadCount = 0,
    List<Message>? messages,
  }) : messages = messages ?? [];

  Message? get lastMessage => messages.isNotEmpty ? messages.last : null;
}
