class ChatModel {
  final String id;
  final String name;
  final String avatarInitial;
  final int avatarColorSeed;
  final bool isGroup;
  final String lastMessageText;
  final DateTime? lastMessageTime;
  final bool lastMessageSentByMe;
  final int unreadCount;

  const ChatModel({
    required this.id,
    required this.name,
    required this.avatarInitial,
    required this.avatarColorSeed,
    this.isGroup = false,
    this.lastMessageText = '',
    this.lastMessageTime,
    this.lastMessageSentByMe = false,
    this.unreadCount = 0,
  });
}
