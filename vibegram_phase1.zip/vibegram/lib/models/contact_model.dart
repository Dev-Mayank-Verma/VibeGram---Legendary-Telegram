class Contact {
  final String name;
  final String initial;
  final int seed;

  const Contact({required this.name, required this.initial, required this.seed});
}
