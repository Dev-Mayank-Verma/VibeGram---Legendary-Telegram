enum MessageStatus { sent, delivered, read }

enum MessageType { text, image, document, audio }

class Message {
  final String id;
  final String text;
  final DateTime time;
  final bool isSentByMe;
  final MessageStatus status;
  final String? senderName; // shown for group-chat messages from others
  final MessageType type;
  final String? replyToText; // set when this message is a reply to another
  final String? replyToSender; // 'You' or the original sender's name

  const Message({
    required this.id,
    required this.text,
    required this.time,
    required this.isSentByMe,
    this.status = MessageStatus.sent,
    this.senderName,
    this.type = MessageType.text,
    this.replyToText,
    this.replyToSender,
  });
}
