class ChannelPost {
  final String id;
  final String text;
  final DateTime time;
  final int likeCount;

  const ChannelPost({
    required this.id,
    required this.text,
    required this.time,
    this.likeCount = 0,
  });
}

class ChannelModel {
  final String id;
  final String name;
  final String avatarInitial;
  final int avatarColorSeed;
  final int subscriberCount;
  final List<ChannelPost> posts;
  bool isSubscribed;

  ChannelModel({
    required this.id,
    required this.name,
    required this.avatarInitial,
    required this.avatarColorSeed,
    required this.subscriberCount,
    this.isSubscribed = false,
    List<ChannelPost>? posts,
  }) : posts = posts ?? [];

  ChannelPost? get lastPost => posts.isNotEmpty ? posts.last : null;
}
