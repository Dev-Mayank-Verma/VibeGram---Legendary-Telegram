import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/channel_provider.dart';
import '../../theme/app_colors.dart';
import '../../widgets/custom_avatar.dart';

class ChannelDetailScreen extends StatelessWidget {
  final String channelId;
  const ChannelDetailScreen({super.key, required this.channelId});

  String _formatCount(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return '$n';
  }

  @override
  Widget build(BuildContext context) {
    final channel = context.watch<ChannelProvider>().getChannelById(channelId);

    return Scaffold(
      backgroundColor: AppColors.chatBackground,
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(
          children: [
            CustomAvatar(initial: channel.avatarInitial, colorSeed: channel.avatarColorSeed, radius: 18),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(channel.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                  Text(
                    '${_formatCount(channel.subscriberCount)} subscribers',
                    style: const TextStyle(fontSize: 12, color: Colors.white70),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            color: Colors.white,
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'Channels are one-way broadcasts — only the admin can post here.',
                    style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: channel.isSubscribed ? AppColors.dividerGrey : AppColors.accentGreen,
                    foregroundColor: channel.isSubscribed ? AppColors.textPrimary : Colors.white,
                  ),
                  onPressed: () => context.read<ChannelProvider>().toggleSubscribe(channel.id),
                  child: Text(channel.isSubscribed ? 'Subscribed' : 'Subscribe'),
                ),
              ],
            ),
          ),
          Expanded(
            child: channel.posts.isEmpty
                ? const Center(child: Text('No posts yet'))
                : ListView.builder(
                    padding: const EdgeInsets.all(10),
                    itemCount: channel.posts.length,
                    itemBuilder: (context, index) {
                      final post = channel.posts[index];
                      return Container(
                        width: double.infinity,
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(post.text, style: const TextStyle(fontSize: 15)),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                const Icon(Icons.favorite_border, size: 16, color: AppColors.textSecondary),
                                const SizedBox(width: 4),
                                Text(
                                  '${post.likeCount}',
                                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                                ),
                                const Spacer(),
                                Text(
                                  DateFormat('d MMM, h:mm a').format(post.time),
                                  style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
