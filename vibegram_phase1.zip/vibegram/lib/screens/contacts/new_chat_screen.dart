import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/chat_provider.dart';
import '../../theme/app_colors.dart';
import '../chat/chat_screen.dart';

/// Real contact discovery is by phone number lookup for now — there's
/// no contacts-sync feature yet, so this only finds people who already
/// have VibeGram installed and have signed in at least once.
class NewChatScreen extends StatefulWidget {
  const NewChatScreen({super.key});

  @override
  State<NewChatScreen> createState() => _NewChatScreenState();
}

class _NewChatScreenState extends State<NewChatScreen> {
  final _phoneController = TextEditingController();
  bool _searching = false;
  String? _error;

  Future<void> _findAndStartChat() async {
    final number = _phoneController.text.trim();
    if (number.length < 10) {
      setState(() => _error = 'Enter a valid phone number');
      return;
    }
    setState(() {
      _searching = true;
      _error = null;
    });

    final fullNumber = number.startsWith('+') ? number : '+91$number';

    if (fullNumber == FirebaseAuth.instance.currentUser?.phoneNumber) {
      setState(() {
        _searching = false;
        _error = "That's your own number";
      });
      return;
    }

    try {
      final query = await FirebaseFirestore.instance
          .collection('users')
          .where('phoneNumber', isEqualTo: fullNumber)
          .limit(1)
          .get();

      if (query.docs.isEmpty) {
        setState(() {
          _searching = false;
          _error = 'No VibeGram user found with that number yet';
        });
        return;
      }

      final data = query.docs.first.data();
      final otherUid = query.docs.first.id;

      final chatId = await context.read<ChatProvider>().startChat(
            otherUid: otherUid,
            otherName: data['name'] as String? ?? fullNumber,
            otherAvatarSeed: (data['avatarColorSeed'] as int?) ?? 0,
          );

      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: chatId)));
    } catch (e) {
      setState(() {
        _searching = false;
        _error = 'Something went wrong: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Start a chat')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Enter the phone number of someone who already has VibeGram '
              'installed and has signed in at least once.',
              style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                prefixText: '+91  ',
                labelText: 'Phone number',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 12)),
            ],
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: _searching ? null : _findAndStartChat,
                child: _searching
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : const Text('Start chat'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }
}
