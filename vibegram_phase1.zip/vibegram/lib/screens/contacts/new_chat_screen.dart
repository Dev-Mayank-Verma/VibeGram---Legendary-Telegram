import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../data/dummy_data.dart';
import '../../models/chat_model.dart';
import '../../providers/chat_provider.dart';
import '../../widgets/custom_avatar.dart';
import '../chat/chat_screen.dart';

class NewChatScreen extends StatelessWidget {
  const NewChatScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final contacts = DummyData.getContacts();

    return Scaffold(
      appBar: AppBar(title: const Text('Select contact')),
      body: ListView.builder(
        itemCount: contacts.length,
        itemBuilder: (context, index) {
          final c = contacts[index];
          return ListTile(
            leading: CustomAvatar(initial: c.initial, colorSeed: c.seed, radius: 22),
            title: Text(c.name),
            subtitle: const Text('Hey there! I am using VibeGram'),
            onTap: () {
              final chatProvider = context.read<ChatProvider>();
              ChatModel? existing;
              for (final chat in chatProvider.chats) {
                if (chat.name == c.name) {
                  existing = chat;
                  break;
                }
              }
              existing ??= chatProvider.addChat(name: c.name, initial: c.initial, seed: c.seed);
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => ChatScreen(chatId: existing!.id)),
              );
            },
          );
        },
      ),
    );
  }
}
