import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/chat_provider.dart';
import '../../theme/app_colors.dart';
import '../../widgets/custom_avatar.dart';
import '../chat/chat_screen.dart';

class NewGroupScreen extends StatefulWidget {
  const NewGroupScreen({super.key});

  @override
  State<NewGroupScreen> createState() => _NewGroupScreenState();
}

class _NewGroupScreenState extends State<NewGroupScreen> {
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final List<Map<String, dynamic>> _members = [];
  bool _searching = false;
  bool _creating = false;
  String? _error;

  Future<void> _addMember() async {
    final number = _phoneController.text.trim();
    if (number.length < 10) {
      setState(() => _error = 'Enter a valid phone number');
      return;
    }
    setState(() {
      _searching = true;
      _error = null;
    });

    final fullNumber = number.startsWith('+') ? number : '+91$number';

    final query = await FirebaseFirestore.instance
        .collection('users')
        .where('phoneNumber', isEqualTo: fullNumber)
        .limit(1)
        .get();

    if (query.docs.isEmpty) {
      setState(() {
        _searching = false;
        _error = 'No VibeGram user found with that number';
      });
      return;
    }

    final data = query.docs.first.data();
    final uid = query.docs.first.id;

    if (_members.any((m) => m['uid'] == uid)) {
      setState(() {
        _searching = false;
        _error = 'Already added';
      });
      return;
    }

    setState(() {
      _members.add({
        'uid': uid,
        'name': data['name'] ?? fullNumber,
        'avatarColorSeed': data['avatarColorSeed'] ?? 0,
      });
      _phoneController.clear();
      _searching = false;
    });
  }

  Future<void> _create() async {
    final name = _nameController.text.trim();
    if (name.isEmpty || _members.isEmpty) return;
    setState(() => _creating = true);

    final chatId = await context.read<ChatProvider>().createGroup(name: name, members: _members);

    if (!mounted) return;
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: chatId)));
  }

  @override
  Widget build(BuildContext context) {
    final canCreate = _nameController.text.trim().isNotEmpty && _members.isNotEmpty && !_creating;

    return Scaffold(
      appBar: AppBar(title: const Text('New group')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _nameController,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                labelText: 'Group name',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    decoration: InputDecoration(
                      prefixText: '+91  ',
                      labelText: 'Add by phone number',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  onPressed: _searching ? null : _addMember,
                  icon: _searching
                      ? const SizedBox(
                          height: 16,
                          width: 16,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Icon(Icons.add),
                ),
              ],
            ),
            if (_error != null) ...[
              const SizedBox(height: 6),
              Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 12)),
            ],
            const SizedBox(height: 16),
            Text('${_members.length} member(s) added', style: const TextStyle(color: AppColors.textSecondary)),
            Expanded(
              child: ListView.builder(
                itemCount: _members.length,
                itemBuilder: (context, index) {
                  final m = _members[index];
                  final name = m['name'] as String;
                  return ListTile(
                    leading: CustomAvatar(
                      initial: name.isNotEmpty ? name[0] : '?',
                      colorSeed: m['avatarColorSeed'] as int,
                      radius: 20,
                    ),
                    title: Text(name),
                    trailing: IconButton(
                      icon: const Icon(Icons.close, size: 18),
                      onPressed: () => setState(() => _members.removeAt(index)),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: canCreate ? AppColors.accentGreen : AppColors.dividerGrey,
        onPressed: canCreate ? _create : null,
        child: _creating
            ? const SizedBox(
                height: 20,
                width: 20,
                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
              )
            : const Icon(Icons.check, color: Colors.white),
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }
}
