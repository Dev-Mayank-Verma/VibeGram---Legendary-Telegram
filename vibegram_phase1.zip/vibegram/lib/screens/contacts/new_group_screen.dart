import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../data/dummy_data.dart';
import '../../providers/chat_provider.dart';
import '../../theme/app_colors.dart';
import '../../widgets/custom_avatar.dart';
import '../chat/chat_screen.dart';

class NewGroupScreen extends StatefulWidget {
  const NewGroupScreen({super.key});

  @override
  State<NewGroupScreen> createState() => _NewGroupScreenState();
}

class _NewGroupScreenState extends State<NewGroupScreen> {
  final Set<String> _selectedNames = {};
  final TextEditingController _nameController = TextEditingController();

  void _toggle(String name) {
    setState(() {
      if (_selectedNames.contains(name)) {
        _selectedNames.remove(name);
      } else {
        _selectedNames.add(name);
      }
    });
  }

  void _create() {
    final name = _nameController.text.trim();
    if (name.isEmpty || _selectedNames.isEmpty) return;
    final group = context.read<ChatProvider>().createGroup(
          name: name,
          memberNames: _selectedNames.toList(),
        );
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => ChatScreen(chatId: group.id)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final contacts = DummyData.getContacts();
    final canCreate = _nameController.text.trim().isNotEmpty && _selectedNames.isNotEmpty;

    return Scaffold(
      appBar: AppBar(title: const Text('New group')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _nameController,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                labelText: 'Group name',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                '${_selectedNames.length} selected',
                style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: contacts.length,
              itemBuilder: (context, index) {
                final c = contacts[index];
                final selected = _selectedNames.contains(c.name);
                return CheckboxListTile(
                  value: selected,
                  onChanged: (_) => _toggle(c.name),
                  secondary: CustomAvatar(initial: c.initial, colorSeed: c.seed, radius: 20),
                  title: Text(c.name),
                  activeColor: AppColors.accentGreen,
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: canCreate ? AppColors.accentGreen : AppColors.dividerGrey,
        onPressed: canCreate ? _create : null,
        child: const Icon(Icons.check, color: Colors.white),
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }
}
