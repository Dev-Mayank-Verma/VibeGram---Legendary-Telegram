import 'dart:async';
import 'package:flutter/material.dart';
import '../../theme/app_colors.dart';
import '../../widgets/custom_avatar.dart';

/// UI preview of a call screen. Looks and behaves like a real call
/// (connecting → timer → mute/speaker → end), but no audio/video is
/// actually transmitted yet — that needs a WebRTC provider (Agora,
/// Stream Video, or Twilio) wired in on top of this screen later.
class CallingScreen extends StatefulWidget {
  final String name;
  final String avatarInitial;
  final int avatarColorSeed;
  final bool isVideo;

  const CallingScreen({
    super.key,
    required this.name,
    required this.avatarInitial,
    required this.avatarColorSeed,
    required this.isVideo,
  });

  @override
  State<CallingScreen> createState() => _CallingScreenState();
}

class _CallingScreenState extends State<CallingScreen> {
  Timer? _timer;
  int _seconds = 0;
  bool _connected = false;
  bool _muted = false;
  bool _speaker = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;
      setState(() => _connected = true);
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) setState(() => _seconds++);
      });
    });
  }

  String get _formattedDuration {
    final m = (_seconds ~/ 60).toString().padLeft(2, '0');
    final s = (_seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBarDark,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 40),
            Text(
              widget.isVideo ? 'Video call' : 'Voice call',
              style: const TextStyle(color: Colors.white70, fontSize: 14),
            ),
            const SizedBox(height: 60),
            CustomAvatar(initial: widget.avatarInitial, colorSeed: widget.avatarColorSeed, radius: 60),
            const SizedBox(height: 20),
            Text(
              widget.name,
              style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 10),
            Text(
              _connected ? _formattedDuration : 'Calling...',
              style: const TextStyle(color: Colors.white70, fontSize: 15),
            ),
            const SizedBox(height: 6),
            if (!_connected)
              const Text(
                '(UI preview — real calling needs a WebRTC provider)',
                style: TextStyle(color: Colors.white38, fontSize: 11),
              ),
            const Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _controlButton(
                  icon: _muted ? Icons.mic_off : Icons.mic,
                  label: 'Mute',
                  active: _muted,
                  onTap: () => setState(() => _muted = !_muted),
                ),
                _controlButton(
                  icon: _speaker ? Icons.volume_up : Icons.volume_down,
                  label: 'Speaker',
                  active: _speaker,
                  onTap: () => setState(() => _speaker = !_speaker),
                ),
              ],
            ),
            const SizedBox(height: 30),
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 64,
                height: 64,
                decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                child: const Icon(Icons.call_end, color: Colors.white, size: 30),
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _controlButton({
    required IconData icon,
    required String label,
    required bool active,
    required VoidCallback onTap,
  }) {
    return Column(
      children: [
        GestureDetector(
          onTap: onTap,
          child: Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(color: active ? Colors.white : Colors.white24, shape: BoxShape.circle),
            child: Icon(icon, color: active ? AppColors.appBarDark : Colors.white),
          ),
        ),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
      ],
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
