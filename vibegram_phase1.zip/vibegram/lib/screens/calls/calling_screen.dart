import 'dart:async';
import 'package:flutter/material.dart';
import '../../services/agora_service.dart';
import '../../theme/app_colors.dart';
import '../../widgets/custom_avatar.dart';

/// Real call screen backed by Agora. Right now both sides need to call
/// the same contact name for it to connect them to the same channel —
/// there's no push-based "incoming call" signaling yet (that needs FCM,
/// which lands with the Firebase phase).
class CallingScreen extends StatefulWidget {
  final String name;
  final String avatarInitial;
  final int avatarColorSeed;
  final bool isVideo;

  const CallingScreen({
    super.key,
    required this.name,
    required this.avatarInitial,
    required this.avatarColorSeed,
    required this.isVideo,
  });

  @override
  State<CallingScreen> createState() => _CallingScreenState();
}

class _CallingScreenState extends State<CallingScreen> {
  late final AgoraService _agora;
  bool _connecting = true;
  Timer? _durationTimer;
  int _seconds = 0;
  bool _wasRemoteJoined = false;

  String get _channelName =>
      'vibegram_${widget.name.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '_')}';

  @override
  void initState() {
    super.initState();
    _agora = AgoraService()..addListener(_onAgoraUpdate);
    _startCall();
  }

  Future<void> _startCall() async {
    await _agora.joinCall(channelName: _channelName, isVideo: widget.isVideo);
    if (mounted) setState(() => _connecting = false);
  }

  void _onAgoraUpdate() {
    if (!mounted) return;
    if (_agora.remoteJoined && !_wasRemoteJoined) {
      _wasRemoteJoined = true;
      _durationTimer?.cancel();
      _seconds = 0;
      _durationTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) setState(() => _seconds++);
      });
    }
    setState(() {});
  }

  String get _formattedDuration {
    final m = (_seconds ~/ 60).toString().padLeft(2, '0');
    final s = (_seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  String get _statusText {
    if (_connecting) return 'Connecting...';
    if (_agora.error != null) return 'Could not connect';
    if (_agora.remoteJoined) return _formattedDuration;
    if (_agora.joined) return 'Waiting for ${widget.name} to join...';
    return 'Calling...';
  }

  Future<void> _endCall() async {
    await _agora.leaveCall();
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appBarDark,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 40),
            Text(
              widget.isVideo ? 'Video call' : 'Voice call',
              style: const TextStyle(color: Colors.white70, fontSize: 14),
            ),
            const SizedBox(height: 60),
            CustomAvatar(initial: widget.avatarInitial, colorSeed: widget.avatarColorSeed, radius: 60),
            const SizedBox(height: 20),
            Text(
              widget.name,
              style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 10),
            Text(_statusText, style: const TextStyle(color: Colors.white70, fontSize: 15)),
            if (_agora.error != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(32, 10, 32, 0),
                child: Text(
                  _agora.error!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.orangeAccent, fontSize: 12),
                ),
              ),
            const Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _controlButton(
                  icon: _agora.muted ? Icons.mic_off : Icons.mic,
                  label: 'Mute',
                  active: _agora.muted,
                  onTap: () => _agora.toggleMute(),
                ),
                _controlButton(
                  icon: _agora.speakerOn ? Icons.volume_up : Icons.volume_down,
                  label: 'Speaker',
                  active: _agora.speakerOn,
                  onTap: () => _agora.toggleSpeaker(),
                ),
              ],
            ),
            const SizedBox(height: 30),
            GestureDetector(
              onTap: _endCall,
              child: Container(
                width: 64,
                height: 64,
                decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                child: const Icon(Icons.call_end, color: Colors.white, size: 30),
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _controlButton({
    required IconData icon,
    required String label,
    required bool active,
    required VoidCallback onTap,
  }) {
    return Column(
      children: [
        GestureDetector(
          onTap: onTap,
          child: Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(color: active ? Colors.white : Colors.white24, shape: BoxShape.circle),
            child: Icon(icon, color: active ? AppColors.appBarDark : Colors.white),
          ),
        ),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
      ],
    );
  }

  @override
  void dispose() {
    _durationTimer?.cancel();
    _agora.removeListener(_onAgoraUpdate);
    _agora.leaveCall();
    super.dispose();
  }
}
