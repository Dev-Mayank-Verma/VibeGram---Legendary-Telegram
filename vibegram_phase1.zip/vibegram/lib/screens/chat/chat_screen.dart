import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../models/message_model.dart';
import '../../providers/chat_provider.dart';
import '../../theme/app_colors.dart';
import '../../widgets/custom_avatar.dart';
import '../../widgets/message_bubble.dart';
import '../calls/calling_screen.dart';

class ChatScreen extends StatefulWidget {
  final String chatId;
  const ChatScreen({super.key, required this.chatId});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  Message? _replyingTo;
  late final Stream<List<Message>> _messagesStream;

  @override
  void initState() {
    super.initState();
    // Cached once so we don't resubscribe to Firestore on every rebuild.
    _messagesStream = context.read<ChatProvider>().messagesStream(widget.chatId);
  }

  void _send() {
    final text = _controller.text;
    if (text.trim().isEmpty) return;
    final chatProvider = context.read<ChatProvider>();

    chatProvider.sendMessage(
      widget.chatId,
      text,
      replyToText: _replyingTo?.text,
      replyToSender: _replyingTo == null
          ? null
          : (_replyingTo!.isSentByMe ? 'You' : (_replyingTo!.senderName ?? 'them')),
    );
    _controller.clear();
    setState(() => _replyingTo = null);
    Future.delayed(const Duration(milliseconds: 150), _scrollToBottom);
  }

  void _sendAttachment(MessageType type, String label) {
    context.read<ChatProvider>().sendMessage(widget.chatId, label, type: type);
    Future.delayed(const Duration(milliseconds: 150), _scrollToBottom);
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    }
  }

  void _startCall(String name, String initial, int seed, bool isVideo) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CallingScreen(name: name, avatarInitial: initial, avatarColorSeed: seed, isVideo: isVideo),
      ),
    );
  }

  void _showMessageActions(Message message) {
    showModalBottomSheet(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.reply),
              title: const Text('Reply'),
              onTap: () {
                Navigator.pop(sheetContext);
                setState(() => _replyingTo = message);
              },
            ),
            if (message.type == MessageType.text)
              ListTile(
                leading: const Icon(Icons.copy),
                title: const Text('Copy'),
                onTap: () {
                  Clipboard.setData(ClipboardData(text: message.text));
                  Navigator.pop(sheetContext);
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Copied')));
                },
              ),
            if (message.isSentByMe)
              ListTile(
                leading: const Icon(Icons.delete_outline, color: Colors.red),
                title: const Text('Delete', style: TextStyle(color: Colors.red)),
                onTap: () {
                  Navigator.pop(sheetContext);
                  context.read<ChatProvider>().deleteMessage(widget.chatId, message.id);
                },
              ),
          ],
        ),
      ),
    );
  }

  void _openAttachmentSheet() {
    showModalBottomSheet(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_outlined, color: AppColors.tealMedium),
              title: const Text('Photo'),
              onTap: () {
                Navigator.pop(sheetContext);
                _sendAttachment(MessageType.image, 'Photo');
              },
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt_outlined, color: AppColors.tealMedium),
              title: const Text('Camera'),
              onTap: () {
                Navigator.pop(sheetContext);
                _sendAttachment(MessageType.image, 'Photo');
              },
            ),
            ListTile(
              leading: const Icon(Icons.insert_drive_file_outlined, color: AppColors.tealMedium),
              title: const Text('Document'),
              onTap: () {
                Navigator.pop(sheetContext);
                _sendAttachment(MessageType.document, 'Document');
              },
            ),
            ListTile(
              leading: const Icon(Icons.mic_none_outlined, color: AppColors.tealMedium),
              title: const Text('Audio'),
              onTap: () {
                Navigator.pop(sheetContext);
                _sendAttachment(MessageType.audio, 'Voice message');
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatProvider>().getChatById(widget.chatId);

    if (chat == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      backgroundColor: AppColors.chatBackground,
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(
          children: [
            CustomAvatar(
              initial: chat.avatarInitial,
              colorSeed: chat.avatarColorSeed,
              radius: 18,
              isGroup: chat.isGroup,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(chat.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.videocam),
            onPressed: () => _startCall(chat.name, chat.avatarInitial, chat.avatarColorSeed, true),
          ),
          IconButton(
            icon: const Icon(Icons.call),
            onPressed: () => _startCall(chat.name, chat.avatarInitial, chat.avatarColorSeed, false),
          ),
          IconButton(icon: const Icon(Icons.more_vert), onPressed: () {}),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<List<Message>>(
              stream: _messagesStream,
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text('Could not load messages: ${snapshot.error}',
                          textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textSecondary)),
                    ),
                  );
                }
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final messages = snapshot.data!;
                if (messages.isEmpty) {
                  return const Center(
                    child: Text('No messages yet — say hi 👋', style: TextStyle(color: AppColors.textSecondary)),
                  );
                }
                WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
                return ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  itemCount: messages.length,
                  itemBuilder: (context, index) => MessageBubble(
                    message: messages[index],
                    onLongPress: () => _showMessageActions(messages[index]),
                  ),
                );
              },
            ),
          ),
          if (_replyingTo != null) _buildReplyBar(),
          _buildInputBar(),
        ],
      ),
    );
  }

  Widget _buildReplyBar() {
    final replying = _replyingTo!;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      color: const Color(0xFFF0F0F0),
      child: Row(
        children: [
          Container(width: 3, height: 34, color: AppColors.tealMedium, margin: const EdgeInsets.only(right: 8)),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  replying.isSentByMe ? 'Replying to yourself' : 'Replying to ${replying.senderName ?? "message"}',
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.tealMedium),
                ),
                Text(
                  replying.text,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.close, size: 18, color: AppColors.iconGrey),
            onPressed: () => setState(() => _replyingTo = null),
          ),
        ],
      ),
    );
  }

  Widget _buildInputBar() {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        color: const Color(0xFFF0F0F0),
        child: Row(
          children: [
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
                child: Row(
                  children: [
                    const Icon(Icons.emoji_emotions_outlined, color: AppColors.iconGrey),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        minLines: 1,
                        maxLines: 5,
                        decoration: const InputDecoration(
                          hintText: 'Message',
                          border: InputBorder.none,
                          isDense: true,
                          contentPadding: EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.attach_file, color: AppColors.iconGrey),
                      onPressed: _openAttachmentSheet,
                    ),
                    IconButton(
                      icon: const Icon(Icons.camera_alt_outlined, color: AppColors.iconGrey),
                      onPressed: () => _sendAttachment(MessageType.image, 'Photo'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 6),
            CircleAvatar(
              radius: 22,
              backgroundColor: AppColors.accentGreen,
              child: ValueListenableBuilder<TextEditingValue>(
                valueListenable: _controller,
                builder: (context, value, child) {
                  final hasText = value.text.trim().isNotEmpty;
                  return IconButton(
                    icon: Icon(hasText ? Icons.send : Icons.mic, color: Colors.white, size: 20),
                    onPressed: hasText
                        ? _send
                        : () => ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Voice notes are coming in a future update')),
                            ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }
}
