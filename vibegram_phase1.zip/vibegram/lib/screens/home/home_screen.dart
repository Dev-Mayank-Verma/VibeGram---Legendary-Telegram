import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/user_provider.dart';
import '../../services/auth_service.dart';
import '../../theme/app_colors.dart';
import '../auth/phone_login_screen.dart';
import '../contacts/new_chat_screen.dart';
import '../contacts/new_group_screen.dart';
import '../profile/profile_screen.dart';
import 'tabs/calls_tab.dart';
import 'tabs/channels_tab.dart';
import 'tabs/chats_tab.dart';
import 'tabs/reels_tab.dart';
import 'tabs/stories_tab.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  static const List<String> _titles = ['VibeGram', 'Stories', 'Channels', 'Calls', 'Reels'];

  void _handleMenuSelect(String value) {
    if (value == 'logout') {
      AuthService().signOut();
      context.read<UserProvider>().logout();
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const PhoneLoginScreen()),
        (route) => false,
      );
    } else if (value == 'profile') {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen()));
    } else if (value == 'New group') {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const NewGroupScreen()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$value — coming in a future phase')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isReelsTab = _selectedIndex == 4;

    return Scaffold(
      appBar: isReelsTab
          ? null
          : AppBar(
              title: Text(_titles[_selectedIndex], style: const TextStyle(fontWeight: FontWeight.w600)),
              actions: [
                if (_selectedIndex == 0) ...[
                  IconButton(icon: const Icon(Icons.camera_alt_outlined), onPressed: () {}),
                  IconButton(icon: const Icon(Icons.search), onPressed: () {}),
                ],
                PopupMenuButton<String>(
                  onSelected: _handleMenuSelect,
                  itemBuilder: (context) => const [
                    PopupMenuItem(value: 'New group', child: Text('New group')),
                    PopupMenuItem(value: 'profile', child: Text('Profile')),
                    PopupMenuItem(value: 'Settings', child: Text('Settings')),
                    PopupMenuItem(value: 'logout', child: Text('Log out (demo)')),
                  ],
                ),
              ],
            ),
      body: SafeArea(
        top: isReelsTab,
        bottom: false,
        child: IndexedStack(
          index: _selectedIndex,
          children: const [
            ChatsTab(),
            StoriesTab(),
            ChannelsTab(),
            CallsTab(),
            ReelsTab(),
          ],
        ),
      ),
      floatingActionButton: _selectedIndex == 0
          ? FloatingActionButton(
              backgroundColor: AppColors.accentGreen,
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const NewChatScreen()));
              },
              child: const Icon(Icons.chat, color: Colors.white),
            )
          : null,
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        selectedItemColor: AppColors.appBarDark,
        unselectedItemColor: AppColors.iconGrey,
        selectedFontSize: 11,
        unselectedFontSize: 11,
        onTap: (index) => setState(() => _selectedIndex = index),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_bubble_outline),
            activeIcon: Icon(Icons.chat_bubble),
            label: 'Chats',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.auto_awesome_motion_outlined),
            activeIcon: Icon(Icons.auto_awesome_motion),
            label: 'Stories',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.campaign_outlined),
            activeIcon: Icon(Icons.campaign),
            label: 'Channels',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.call_outlined),
            activeIcon: Icon(Icons.call),
            label: 'Calls',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.video_collection_outlined),
            activeIcon: Icon(Icons.video_collection),
            label: 'Reels',
          ),
        ],
      ),
    );
  }
}
