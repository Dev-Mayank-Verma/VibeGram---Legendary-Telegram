import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../providers/channel_provider.dart';
import '../../../theme/app_colors.dart';
import '../../../widgets/custom_avatar.dart';
import '../../channels/channel_detail_screen.dart';

class ChannelsTab extends StatelessWidget {
  const ChannelsTab({super.key});

  String _formatCount(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return '$n';
  }

  @override
  Widget build(BuildContext context) {
    final channels = context.watch<ChannelProvider>().channels;

    return ListView.separated(
      padding: const EdgeInsets.only(top: 4),
      itemCount: channels.length,
      separatorBuilder: (_, __) => const Divider(height: 1, indent: 78),
      itemBuilder: (context, index) {
        final channel = channels[index];
        final last = channel.lastPost;
        return ListTile(
          leading: CustomAvatar(initial: channel.avatarInitial, colorSeed: channel.avatarColorSeed, radius: 26),
          title: Text(channel.name, style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: Text(
            last != null ? last.text : 'No posts yet',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          trailing: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${_formatCount(channel.subscriberCount)} subs',
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
              ),
              const SizedBox(height: 4),
              if (channel.isSubscribed)
                const Icon(Icons.check_circle, color: AppColors.accentGreen, size: 16),
            ],
          ),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ChannelDetailScreen(channelId: channel.id)),
            );
          },
        );
      },
    );
  }
}
