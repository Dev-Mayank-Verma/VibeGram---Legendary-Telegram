import 'package:flutter/material.dart';
import '../../../data/dummy_data.dart';
import '../../../models/reel_model.dart';

class ReelsTab extends StatefulWidget {
  const ReelsTab({super.key});

  @override
  State<ReelsTab> createState() => _ReelsTabState();
}

class _ReelsTabState extends State<ReelsTab> {
  late final List<ReelModel> _reels;

  static const List<List<Color>> _gradients = [
    [Color(0xFF075E54), Color(0xFF128C7E)],
    [Color(0xFF3D5A80), Color(0xFF293241)],
    [Color(0xFF9B5DE5), Color(0xFF5E239D)],
    [Color(0xFFEF8354), Color(0xFFBC4749)],
    [Color(0xFF2A9D8F), Color(0xFF264653)],
  ];

  @override
  void initState() {
    super.initState();
    _reels = DummyData.getSampleReels();
  }

  void _toggleLike(ReelModel reel) {
    setState(() {
      reel.isLiked = !reel.isLiked;
      reel.likeCount += reel.isLiked ? 1 : -1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
      child: PageView.builder(
        scrollDirection: Axis.vertical,
        itemCount: _reels.length,
        itemBuilder: (context, index) {
          final reel = _reels[index];
          final gradient = _gradients[reel.gradientSeed % _gradients.length];
          return Stack(
            fit: StackFit.expand,
            children: [
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: gradient,
                  ),
                ),
                child: const Center(
                  child: Icon(Icons.play_circle_outline, color: Colors.white24, size: 64),
                ),
              ),
              Positioned(
                left: 16,
                right: 90,
                bottom: 24,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '@${reel.username}',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 15),
                    ),
                    const SizedBox(height: 6),
                    Text(reel.caption, style: const TextStyle(color: Colors.white, fontSize: 13)),
                  ],
                ),
              ),
              Positioned(
                right: 12,
                bottom: 24,
                child: Column(
                  children: [
                    IconButton(
                      icon: Icon(
                        reel.isLiked ? Icons.favorite : Icons.favorite_border,
                        color: reel.isLiked ? Colors.redAccent : Colors.white,
                        size: 30,
                      ),
                      onPressed: () => _toggleLike(reel),
                    ),
                    Text('${reel.likeCount}', style: const TextStyle(color: Colors.white, fontSize: 12)),
                    const SizedBox(height: 16),
                    const Icon(Icons.mode_comment_outlined, color: Colors.white, size: 28),
                    const SizedBox(height: 16),
                    const Icon(Icons.send_outlined, color: Colors.white, size: 26),
                  ],
                ),
              ),
              const Positioned(
                top: 16,
                left: 16,
                child: Text(
                  'Reels — UI preview (video upload comes later)',
                  style: TextStyle(color: Colors.white54, fontSize: 11),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
