import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../providers/chat_provider.dart';
import '../../../theme/app_colors.dart';
import '../../../widgets/chat_list_tile.dart';
import '../../chat/chat_screen.dart';

enum _ChatFolder { all, unread, groups, personal }

class ChatsTab extends StatefulWidget {
  const ChatsTab({super.key});

  @override
  State<ChatsTab> createState() => _ChatsTabState();
}

class _ChatsTabState extends State<ChatsTab> {
  _ChatFolder _folder = _ChatFolder.all;

  @override
  Widget build(BuildContext context) {
    final chatProvider = context.watch<ChatProvider>();
    final allChats = chatProvider.chats;

    if (chatProvider.loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (chatProvider.error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            chatProvider.error!,
            textAlign: TextAlign.center,
            style: const TextStyle(color: AppColors.textSecondary),
          ),
        ),
      );
    }

    final filtered = allChats.where((chat) {
      switch (_folder) {
        case _ChatFolder.all:
          return true;
        case _ChatFolder.unread:
          return chat.unreadCount > 0;
        case _ChatFolder.groups:
          return chat.isGroup;
        case _ChatFolder.personal:
          return !chat.isGroup;
      }
    }).toList();

    return Column(
      children: [
        _buildFolderBar(),
        Expanded(
          child: filtered.isEmpty
              ? const Center(child: Text('No chats in this folder'))
              : ListView.separated(
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) => const Divider(height: 1, indent: 78),
                  itemBuilder: (context, index) {
                    final chat = filtered[index];
                    return ChatListTile(
                      chat: chat,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => ChatScreen(chatId: chat.id)),
                        );
                      },
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildFolderBar() {
    final options = {
      _ChatFolder.all: 'All',
      _ChatFolder.unread: 'Unread',
      _ChatFolder.groups: 'Groups',
      _ChatFolder.personal: 'Personal',
    };

    return Container(
      height: 44,
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: options.entries.map((entry) {
          final selected = _folder == entry.key;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: ChoiceChip(
              label: Text(entry.value),
              selected: selected,
              onSelected: (_) => setState(() => _folder = entry.key),
              selectedColor: AppColors.appBarDark,
              labelStyle: TextStyle(
                color: selected ? Colors.white : AppColors.textPrimary,
                fontSize: 13,
                fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
              ),
              backgroundColor: AppColors.chatBackground,
              side: BorderSide.none,
            ),
          );
        }).toList(),
      ),
    );
  }
}
