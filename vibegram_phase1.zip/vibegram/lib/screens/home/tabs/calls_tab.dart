import 'package:flutter/material.dart';
import '../../../data/dummy_data.dart';
import '../../../theme/app_colors.dart';
import '../../../widgets/custom_avatar.dart';
import '../../calls/calling_screen.dart';

class CallsTab extends StatelessWidget {
  const CallsTab({super.key});

  void _startCall(BuildContext context, String name, String initial, int seed, bool isVideo) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CallingScreen(name: name, avatarInitial: initial, avatarColorSeed: seed, isVideo: isVideo),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final contacts = DummyData.getContacts();
    final callTypes = [
      {'icon': Icons.call_missed, 'color': Colors.red, 'label': 'Missed'},
      {'icon': Icons.call_received, 'color': AppColors.accentGreen, 'label': 'Incoming'},
      {'icon': Icons.call_made, 'color': AppColors.accentGreen, 'label': 'Outgoing'},
    ];

    return ListView.builder(
      itemCount: contacts.length,
      itemBuilder: (context, index) {
        final c = contacts[index];
        final type = callTypes[index % callTypes.length];
        return ListTile(
          leading: CustomAvatar(initial: c.initial, colorSeed: c.seed, radius: 24),
          title: Text(c.name),
          subtitle: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(type['icon'] as IconData, size: 16, color: type['color'] as Color),
              const SizedBox(width: 4),
              Text('${type['label']}, Today'),
            ],
          ),
          trailing: IconButton(
            icon: const Icon(Icons.call, color: AppColors.appBarDark, size: 20),
            onPressed: () => _startCall(context, c.name, c.initial, c.seed, false),
          ),
          onTap: () => _startCall(context, c.name, c.initial, c.seed, false),
        );
      },
    );
  }
}
