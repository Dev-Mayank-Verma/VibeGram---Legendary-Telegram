import 'package:flutter/material.dart';
import '../../../data/dummy_data.dart';
import '../../../theme/app_colors.dart';
import '../../../widgets/custom_avatar.dart';

class StoriesTab extends StatelessWidget {
  const StoriesTab({super.key});

  @override
  Widget build(BuildContext context) {
    final contacts = DummyData.getContacts();

    return ListView(
      children: [
        ListTile(
          leading: Stack(
            clipBehavior: Clip.none,
            children: [
              const CustomAvatar(initial: 'Y', colorSeed: 0, radius: 26),
              Positioned(
                right: -2,
                bottom: -2,
                child: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: const BoxDecoration(color: AppColors.accentGreen, shape: BoxShape.circle),
                  child: const Icon(Icons.add, color: Colors.white, size: 14),
                ),
              ),
            ],
          ),
          title: const Text('My story', style: TextStyle(fontWeight: FontWeight.w600)),
          subtitle: const Text('Tap to add — visible for 24 hours'),
          onTap: () => _showComingSoon(context, 'Posting a story'),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, 6),
          child: Text(
            'Recent stories',
            style: TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.w600),
          ),
        ),
        ...contacts.map(
          (c) => ListTile(
            leading: Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                border: Border.all(color: AppColors.accentGreen, width: 2),
                shape: BoxShape.circle,
              ),
              child: CustomAvatar(initial: c.initial, colorSeed: c.seed, radius: 24),
            ),
            title: Text(c.name),
            subtitle: const Text('Posted 3h ago · disappears in 21h'),
            onTap: () => _showComingSoon(context, 'Story viewer'),
          ),
        ),
      ],
    );
  }

  void _showComingSoon(BuildContext context, String feature) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$feature is coming in a future update')),
    );
  }
}
