import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/user_provider.dart';
import '../../theme/app_colors.dart';
import '../../widgets/custom_avatar.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<UserProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Center(
            child: CustomAvatar(initial: user.name, colorSeed: user.avatarColorSeed, radius: 50),
          ),
          const SizedBox(height: 16),
          Center(
            child: Text(
              user.name.isNotEmpty ? user.name : 'Demo User',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(height: 4),
          const Center(
            child: Text(
              'Demo profile — no phone number linked yet',
              style: TextStyle(color: AppColors.textSecondary),
            ),
          ),
          const SizedBox(height: 32),
          const _ProfileRow(icon: Icons.info_outline, label: 'About', value: 'Hey there! I am using VibeGram'),
          const _ProfileRow(icon: Icons.phone_outlined, label: 'Phone', value: 'Not linked yet'),
          const _ProfileRow(icon: Icons.notifications_outlined, label: 'Notifications', value: 'On'),
          const _ProfileRow(icon: Icons.lock_outline, label: 'Privacy', value: 'Default'),
        ],
      ),
    );
  }
}

class _ProfileRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _ProfileRow({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Icon(icon, color: AppColors.iconGrey),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                Text(value, style: const TextStyle(fontSize: 15)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
