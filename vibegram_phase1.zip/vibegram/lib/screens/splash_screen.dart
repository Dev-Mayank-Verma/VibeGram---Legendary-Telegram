import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import 'auth/demo_login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const DemoLoginScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: AppColors.appBarDark,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.chat_bubble, color: Colors.white, size: 90),
            SizedBox(height: 16),
            Text(
              'VibeGram',
              style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }
}
