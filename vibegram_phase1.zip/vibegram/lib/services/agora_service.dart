import 'dart:convert';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';

/// Wraps one Agora call session.
///
/// SECURITY: the Agora App ID is safe to ship inside the app — it's
/// injected at build time via --dart-define (see AGORA_APP_ID in the
/// GitHub Actions workflow), not hardcoded here. The App Certificate is
/// NEVER in this file or anywhere in the Flutter app: it lives only
/// inside the token-server Cloud Function (see /functions/index.js).
/// This class calls that server to get a short-lived token before
/// every call instead of using the certificate directly.
class AgoraService extends ChangeNotifier {
  static const String _appId = String.fromEnvironment('AGORA_APP_ID');

  // Set this to your deployed Cloud Function URL once it's live, e.g.
  // https://us-central1-<your-project-id>.cloudfunctions.net/generateAgoraToken
  // Passed at build time so it's easy to update without editing source.
  static const String _tokenEndpoint = String.fromEnvironment('AGORA_TOKEN_URL');

  RtcEngine? _engine;
  bool _joined = false;
  bool _remoteJoined = false;
  bool _muted = false;
  bool _speakerOn = true;
  String? _error;

  bool get joined => _joined;
  bool get remoteJoined => _remoteJoined;
  bool get muted => _muted;
  bool get speakerOn => _speakerOn;
  String? get error => _error;

  Future<String?> _fetchToken(String channelName) async {
    if (_tokenEndpoint.isEmpty) {
      _error = 'Token server not deployed yet (AGORA_TOKEN_URL is empty)';
      return null;
    }
    try {
      final uri = Uri.parse('$_tokenEndpoint?channelName=$channelName');
      final response = await http.get(uri).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        return data['token'] as String?;
      }
      _error = 'Token server returned ${response.statusCode}';
      return null;
    } catch (e) {
      _error = 'Could not reach token server';
      return null;
    }
  }

  Future<bool> joinCall({required String channelName, required bool isVideo}) async {
    _error = null;

    final statuses = await [
      Permission.microphone,
      if (isVideo) Permission.camera,
    ].request();

    if (statuses[Permission.microphone] != PermissionStatus.granted) {
      _error = 'Microphone permission is needed for calls';
      notifyListeners();
      return false;
    }

    if (_appId.isEmpty) {
      _error = 'AGORA_APP_ID was not set at build time';
      notifyListeners();
      return false;
    }

    final token = await _fetchToken(channelName);
    if (token == null) {
      notifyListeners();
      return false;
    }

    _engine = createAgoraRtcEngine();
    await _engine!.initialize(RtcEngineContext(
      appId: _appId,
      channelProfile: ChannelProfileType.channelProfileCommunication,
    ));

    _engine!.registerEventHandler(
      RtcEngineEventHandler(
        onJoinChannelSuccess: (connection, elapsed) {
          _joined = true;
          notifyListeners();
        },
        onUserJoined: (connection, remoteUid, elapsed) {
          _remoteJoined = true;
          notifyListeners();
        },
        onUserOffline: (connection, remoteUid, reason) {
          _remoteJoined = false;
          notifyListeners();
        },
        onError: (err, msg) {
          _error = msg;
          notifyListeners();
        },
      ),
    );

    await _engine!.enableAudio();
    if (isVideo) {
      await _engine!.enableVideo();
    }

    // Voice calls default to earpiece, video calls default to speaker —
    // matches how phone call UIs normally behave.
    _speakerOn = isVideo;
    await _engine!.setEnableSpeakerphone(_speakerOn);

    await _engine!.joinChannel(
      token: token,
      channelId: channelName,
      uid: 0,
      options: ChannelMediaOptions(
        clientRoleType: ClientRoleType.clientRoleBroadcaster,
        channelProfile: ChannelProfileType.channelProfileCommunication,
      ),
    );

    return true;
  }

  Future<void> toggleMute() async {
    _muted = !_muted;
    await _engine?.muteLocalAudioStream(_muted);
    notifyListeners();
  }

  Future<void> toggleSpeaker() async {
    _speakerOn = !_speakerOn;
    await _engine?.setEnableSpeakerphone(_speakerOn);
    notifyListeners();
  }

  Future<void> leaveCall() async {
    await _engine?.leaveChannel();
    await _engine?.release();
    _engine = null;
    _joined = false;
    _remoteJoined = false;
  }
}
