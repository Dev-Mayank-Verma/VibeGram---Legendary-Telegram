import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/chat_model.dart';
import '../models/message_model.dart';
import '../theme/app_colors.dart';
import 'custom_avatar.dart';

class ChatListTile extends StatelessWidget {
  final ChatModel chat;
  final VoidCallback onTap;

  const ChatListTile({super.key, required this.chat, required this.onTap});

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final isToday = now.year == time.year && now.month == time.month && now.day == time.day;
    if (isToday) return DateFormat('h:mm a').format(time);

    final yesterday = now.subtract(const Duration(days: 1));
    final isYesterday =
        yesterday.year == time.year && yesterday.month == time.month && yesterday.day == time.day;
    if (isYesterday) return 'Yesterday';

    return DateFormat('dd/MM/yy').format(time);
  }

  Widget _buildSubtitle(Message? last, bool hasUnread) {
    if (last == null) {
      return const Text('Say hi 👋', style: TextStyle(fontSize: 14, color: AppColors.textSecondary));
    }

    String? prefix;
    if (last.isSentByMe) {
      prefix = 'You: ';
    } else if (chat.isGroup && last.senderName != null) {
      prefix = '${last.senderName}: ';
    }

    final baseColor = hasUnread ? AppColors.textPrimary : AppColors.textSecondary;
    final baseWeight = hasUnread ? FontWeight.w500 : FontWeight.normal;

    return RichText(
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      text: TextSpan(
        children: [
          if (prefix != null)
            TextSpan(
              text: prefix,
              style: TextStyle(fontSize: 14, color: baseColor, fontWeight: FontWeight.w600),
            ),
          TextSpan(
            text: last.text,
            style: TextStyle(fontSize: 14, color: baseColor, fontWeight: baseWeight),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final last = chat.lastMessage;
    final hasUnread = chat.unreadCount > 0;

    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            CustomAvatar(
              initial: chat.avatarInitial,
              colorSeed: chat.avatarColorSeed,
              radius: 26,
              isGroup: chat.isGroup,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    chat.name,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 3),
                  _buildSubtitle(last, hasUnread),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  last != null ? _formatTime(last.time) : '',
                  style: TextStyle(
                    fontSize: 12,
                    color: hasUnread ? AppColors.accentGreen : AppColors.textSecondary,
                    fontWeight: hasUnread ? FontWeight.w600 : FontWeight.normal,
                  ),
                ),
                const SizedBox(height: 6),
                if (hasUnread)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                    constraints: const BoxConstraints(minWidth: 22),
                    decoration: const BoxDecoration(
                      color: AppColors.unreadBadge,
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      '${chat.unreadCount}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
