import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

class CustomAvatar extends StatelessWidget {
  final String initial;
  final int colorSeed;
  final double radius;
  final bool showOnlineDot;
  final bool isGroup;

  const CustomAvatar({
    super.key,
    required this.initial,
    required this.colorSeed,
    this.radius = 24,
    this.showOnlineDot = false,
    this.isGroup = false,
  });

  static const List<Color> _palette = [
    Color(0xFF075E54),
    Color(0xFF128C7E),
    Color(0xFFE07A5F),
    Color(0xFF3D5A80),
    Color(0xFF9B5DE5),
    Color(0xFFEF8354),
    Color(0xFF2A9D8F),
    Color(0xFF457B9D),
    Color(0xFF6A4C93),
    Color(0xFFD62828),
  ];

  @override
  Widget build(BuildContext context) {
    final color = _palette[colorSeed % _palette.length];
    return Stack(
      clipBehavior: Clip.none,
      children: [
        CircleAvatar(
          radius: radius,
          backgroundColor: color,
          child: isGroup
              ? Icon(Icons.groups, color: Colors.white, size: radius * 0.9)
              : Text(
                  initial.isNotEmpty ? initial.substring(0, 1).toUpperCase() : '?',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: radius * 0.7,
                    fontWeight: FontWeight.w600,
                  ),
                ),
        ),
        if (showOnlineDot)
          Positioned(
            right: 0,
            bottom: 0,
            child: Container(
              width: radius * 0.4,
              height: radius * 0.4,
              decoration: BoxDecoration(
                color: AppColors.accentGreen,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
            ),
          ),
      ],
    );
  }
}
