import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/message_model.dart';
import '../theme/app_colors.dart';

class MessageBubble extends StatelessWidget {
  final Message message;
  final VoidCallback? onLongPress;

  const MessageBubble({super.key, required this.message, this.onLongPress});

  IconData get _typeIcon {
    switch (message.type) {
      case MessageType.image:
        return Icons.image_outlined;
      case MessageType.document:
        return Icons.insert_drive_file_outlined;
      case MessageType.audio:
        return Icons.mic_none_outlined;
      case MessageType.text:
        return Icons.text_fields;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isMe = message.isSentByMe;

    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: onLongPress,
        child: Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
          margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 8),
          padding: const EdgeInsets.fromLTRB(10, 7, 8, 6),
          decoration: BoxDecoration(
            color: isMe ? AppColors.bubbleSent : AppColors.bubbleReceived,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(8),
              topRight: const Radius.circular(8),
              bottomLeft: Radius.circular(isMe ? 8 : 0),
              bottomRight: Radius.circular(isMe ? 0 : 8),
            ),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 1, offset: const Offset(0, 1)),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!isMe && message.senderName != null) ...[
                Text(
                  message.senderName!,
                  style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppColors.tealMedium),
                ),
                const SizedBox(height: 2),
              ],
              if (message.replyToText != null) _buildReplyPreview(),
              if (message.type == MessageType.text)
                Text(message.text, style: const TextStyle(fontSize: 15, color: AppColors.textPrimary))
              else
                _buildAttachmentContent(),
              const SizedBox(height: 3),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    DateFormat('h:mm a').format(message.time),
                    style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                  ),
                  if (isMe) ...[
                    const SizedBox(width: 4),
                    Icon(
                      message.status == MessageStatus.read ? Icons.done_all : Icons.done,
                      size: 15,
                      color: message.status == MessageStatus.read
                          ? AppColors.tickBlue
                          : AppColors.textSecondary,
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildReplyPreview() {
    return Container(
      margin: const EdgeInsets.only(bottom: 5),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.04),
        borderRadius: BorderRadius.circular(6),
        border: const Border(left: BorderSide(color: AppColors.tealMedium, width: 3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            message.replyToSender ?? 'You',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.tealMedium),
          ),
          Text(
            message.replyToText!,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }

  Widget _buildAttachmentContent() {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(color: Colors.black.withOpacity(0.05), borderRadius: BorderRadius.circular(6)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(_typeIcon, size: 20, color: AppColors.tealMedium),
          const SizedBox(width: 8),
          Text(message.text, style: const TextStyle(fontSize: 14, color: AppColors.textPrimary)),
        ],
      ),
    );
  }
}
