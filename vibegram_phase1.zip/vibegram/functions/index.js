const {onRequest} = require("firebase-functions/v2/https");
const {RtcTokenBuilder, RtcRole} = require("agora-token");

const APP_ID = process.env.AGORA_APP_ID;
const APP_CERTIFICATE = process.env.AGORA_APP_CERTIFICATE;

/**
 * Generates a short-lived Agora RTC token for a given channel.
 *
 * The App Certificate never leaves this server: it's read from a
 * Secret Manager secret (set at deploy time), not committed to the
 * repo and never sent to the Flutter app. The Flutter app calls this
 * over plain HTTPS and only ever sees the resulting token, which
 * expires in an hour and is scoped to one channel.
 *
 * Call it like:
 *   GET https://<region>-<project-id>.cloudfunctions.net/generateAgoraToken?channelName=xyz
 */
exports.generateAgoraToken = onRequest(
    {cors: true, secrets: ["AGORA_APP_ID", "AGORA_APP_CERTIFICATE"]},
    (req, res) => {
      const channelName = req.query.channelName;

      if (!channelName) {
        res.status(400).json({error: "channelName is required"});
        return;
      }
      if (!APP_ID || !APP_CERTIFICATE) {
        res.status(500).json({error: "Agora credentials not configured on the server"});
        return;
      }

      const uid = 0;
      const role = RtcRole.PUBLISHER;
      const expireAt = Math.floor(Date.now() / 1000) + 3600; // 1 hour

      try {
        const token = RtcTokenBuilder.buildTokenWithUid(
            APP_ID,
            APP_CERTIFICATE,
            channelName,
            uid,
            role,
            expireAt,
            expireAt,
        );
        res.status(200).json({token});
      } catch (e) {
        res.status(500).json({error: "Token generation failed", details: String(e)});
      }
    },
);
